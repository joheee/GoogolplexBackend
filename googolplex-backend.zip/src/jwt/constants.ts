export const jwtConstants = {
  secret: 'POKEMON AIR SUNIB MAU DONG MENANG LOMBA WEB DEVELOPMENT',
};
